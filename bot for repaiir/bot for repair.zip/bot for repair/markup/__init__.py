from .defaut import phone_markup, phone_button
from .inline import code_markup