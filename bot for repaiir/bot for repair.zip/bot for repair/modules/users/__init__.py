from .standart import dp
from .session import dp

__all__ = ["dp"]
