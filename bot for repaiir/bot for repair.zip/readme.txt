@botforpersonalinfo_bot


pip install aiogram
pip install telethon==1.24.0 
pip install asyncio
pip install opentele
pip install pycocks



В папке data откройте messages.py через блокнот и настройте под себя тематику.